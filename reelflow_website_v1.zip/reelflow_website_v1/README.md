# ReelFlow — vertical video feed prototype

A tablet-friendly, black-themed scrolling video website built with plain HTML, CSS and JavaScript.

## Run it
Open `index.html` in a browser to test the UI. For best results, publish it using GitHub Pages or another static HTTPS host.

## Automatic feed integration
The page accepts a JSON API endpoint in **Feed settings**. The endpoint must be HTTPS and return either an array of items or an object with an `items` array.

Example response:
```json
{
  "items": [
    {
      "id": "video-123",
      "videoUrl": "https://your-authorized-host.example/video.mp4",
      "creator": "creator-name",
      "caption": "Video caption"
    }
  ]
}
```

An item can instead contain `embedUrl` with an HTTPS embed URL. Only use a source and access method you are authorized to use. Your endpoint must permit browser requests from the published site's origin (CORS).

## Instagram limitation
Instagram's official APIs do not expose a general public, personalized Reels recommendation feed for arbitrary websites. Public post embeds are different from a feed API. Do not put API secrets in `app.js`; if a third-party provider requires a key, call it from a server-side endpoint and keep the key there.

## Files
- `index.html` — page structure
- `style.css` — responsive dark UI
- `app.js` — feed rendering, demo videos, saved items, and endpoint configuration
